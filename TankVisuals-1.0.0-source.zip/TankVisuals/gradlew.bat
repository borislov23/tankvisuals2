@echo off
setlocal
set "GRADLE_VERSION=8.12"
set "BOOTSTRAP_DIR=%~dp0.gradle-bootstrap"
set "GRADLE_HOME=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BOOTSTRAP_DIR%" mkdir "%BOOTSTRAP_DIR%"
  echo Downloading Gradle %GRADLE_VERSION% for the first build...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%BOOTSTRAP_DIR%\gradle.zip'; Expand-Archive -LiteralPath '%BOOTSTRAP_DIR%\gradle.zip' -DestinationPath '%BOOTSTRAP_DIR%' -Force; Remove-Item '%BOOTSTRAP_DIR%\gradle.zip' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
