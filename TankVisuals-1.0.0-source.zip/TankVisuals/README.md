# TankVisuals — Minecraft 1.21.4 (Fabric)

Client-side utility/visual mod with a Right Shift menu.

## Features
- Player HUD: name, health/absorption, health bar when the crosshair targets a player.
- Target circle: configurable colour, radius in config, lower segment count in lightweight mode.
- ClickGUI: Right Shift; toggle modules, set item IDs, rebind swap keys.
- Elytra swap: default `G`; swaps an elytra with the equipped chest item or swaps an equipped elytra for the first chestplate found.
- Offhand swap: default `H`; switches the offhand between configured item IDs (default golden apple/shield).
- Lightweight rendering: uses fewer circle segments to reduce the mod's own rendering work.
- JSON config at `.minecraft/config/tankvisuals.json`.

## Build
Requires JDK 21 and internet access the first time Gradle resolves Minecraft/Fabric dependencies.

```bash
gradle build
```

The output JAR is placed in `build/libs/`.

## Install
1. Install Fabric Loader for Minecraft 1.21.4.
2. Put the built `tankvisuals-1.0.0.jar` in `.minecraft/mods/`.
3. Make sure Fabric API for 1.21.4 is also in `mods/`.
4. Start the game. Open the menu with Right Shift.

## Notes
- This is a client-side mod; it does not need to be installed on the server.
- Multiplayer inventory actions still pass through the server's normal inventory synchronization and may be affected by server latency or server-side restrictions.
- Lightweight rendering reduces this mod's own drawing workload; it is not a substitute for broader FPS optimization mods such as Sodium.
- This environment may not have Gradle or network access, so build the project locally if the JAR is not included.
