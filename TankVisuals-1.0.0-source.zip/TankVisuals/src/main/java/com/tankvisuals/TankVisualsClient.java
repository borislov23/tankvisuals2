package com.tankvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;

public final class TankVisualsClient implements ClientModInitializer {
    public static KeyBinding openGuiKey;
    public static KeyBinding elytraKey;
    public static KeyBinding offhandKey;
    private static PlayerEntity targetedPlayer;

    @Override
    public void onInitializeClient() {
        TVConfig.load();
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.tankvisuals.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.tankvisuals"));
        elytraKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.tankvisuals.elytra_swap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.tankvisuals"));
        offhandKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.tankvisuals.offhand_swap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.tankvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed() && client.currentScreen == null) client.setScreen(new TankVisualsScreen());
            while (elytraKey.wasPressed()) {
                if (TVConfig.get().elytraSwap) ItemSwapper.swapElytra(client);
            }
            while (offhandKey.wasPressed()) {
                if (TVConfig.get().offhandSwap) ItemSwapper.swapOffhand(client);
            }
            targetedPlayer = findTargetedPlayer(client);
        });

        HudRenderCallback.EVENT.register(TankVisualsClient::renderHud);
        WorldRenderEvents.AFTER_ENTITIES.register(context -> renderTargetCircle(context.matrixStack(), context.camera().getPos()));
    }

    public static PlayerEntity getTargetedPlayer() { return targetedPlayer; }

    private static PlayerEntity findTargetedPlayer(MinecraftClient client) {
        if (client.player == null || client.world == null || !(client.crosshairTarget instanceof EntityHitResult hit)) return null;
        Entity entity = hit.getEntity();
        if (!(entity instanceof PlayerEntity player) || player == client.player || !player.isAlive()) return null;
        return player;
    }

    private static void renderHud(DrawContext context, float tickDelta) {
        TVConfig cfg = TVConfig.get();
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity target = targetedPlayer;
        if (!cfg.playerHud || target == null || client.player == null || client.options.hudHidden) return;
        String name = target.getGameProfile().getName();
        float health = Math.max(0, target.getHealth());
        float max = Math.max(1, target.getMaxHealth());
        float absorption = target.getAbsorptionAmount();
        String hp = String.format(java.util.Locale.ROOT, "%.1f / %.0f HP", health + absorption, max);
        int width = Math.max(client.textRenderer.getWidth(name), client.textRenderer.getWidth(hp)) + 24;
        int x = (context.getScaledWindowWidth() - width) / 2;
        int y = context.getScaledWindowHeight() / 2 + 24;
        context.fill(x, y, x + width, y + 38, 0xD911151D);
        context.fill(x, y, x + width, y + 2, cfg.circleColor);
        context.drawCenteredTextWithShadow(client.textRenderer, name, x + width / 2, y + 6, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(client.textRenderer, hp, x + width / 2, y + 20, health <= max * 0.3f ? 0xFFFF7777 : 0xFF8DFFB0);
        int barX = x + 8, barY = y + 32, barW = width - 16;
        context.fill(barX, barY, barX + barW, barY + 3, 0xFF343943);
        context.fill(barX, barY, barX + MathHelper.ceil(barW * MathHelper.clamp(health / max, 0f, 1f)), barY + 3, 0xFF52D273);
    }

    private static void renderTargetCircle(MatrixStack matrices, Vec3d cameraPos) {
        TVConfig cfg = TVConfig.get();
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity target = targetedPlayer;
        if (!cfg.targetCircle || target == null || client.world == null || client.player == null || client.options.hudHidden) return;
        if (matrices == null) return;
        int segments = cfg.lightweightRendering ? 24 : 48;
        float red = ((cfg.circleColor >> 16) & 255) / 255.0f;
        float green = ((cfg.circleColor >> 8) & 255) / 255.0f;
        float blue = (cfg.circleColor & 255) / 255.0f;
        float alpha = ((cfg.circleColor >>> 24) & 255) / 255.0f;
        double radius = MathHelper.clamp(cfg.circleRadius, 0.25, 2.0);
        matrices.push();
        matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        VertexConsumer lines = client.getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getLines());
        MatrixStack.Entry entry = matrices.peek();
        double y = target.getY() + 0.035;
        for (int i = 0; i < segments; i++) {
            double a1 = Math.PI * 2.0 * i / segments;
            double a2 = Math.PI * 2.0 * (i + 1) / segments;
            float x1 = (float) (target.getX() + Math.cos(a1) * radius);
            float z1 = (float) (target.getZ() + Math.sin(a1) * radius);
            float x2 = (float) (target.getX() + Math.cos(a2) * radius);
            float z2 = (float) (target.getZ() + Math.sin(a2) * radius);
            lines.vertex(entry, x1, (float) y, z1).color(red, green, blue, alpha).normal(entry, 0, 1, 0);
            lines.vertex(entry, x2, (float) y, z2).color(red, green, blue, alpha).normal(entry, 0, 1, 0);
        }
        matrices.pop();
    }
}
