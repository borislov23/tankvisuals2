package com.tankvisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;

public final class ItemSwapper {
    private ItemSwapper() {}

    public static void swapElytra(MinecraftClient client) {
        if (!canSwap(client)) return;
        PlayerInventory inv = client.player.getInventory();
        boolean wearingElytra = inv.getArmorStack(2).isOf(Items.ELYTRA);
        if (wearingElytra) {
            int chestplateSlot = findInventorySlot(client, "minecraft:netherite_chestplate", "minecraft:diamond_chestplate", "minecraft:iron_chestplate", "minecraft:golden_chestplate", "minecraft:chainmail_chestplate", "minecraft:leather_chestplate");
            if (chestplateSlot >= 0) swapIntoChest(client, chestplateSlot);
        } else {
            int elytraSlot = findInventorySlot(client, "minecraft:elytra");
            if (elytraSlot >= 0) swapIntoChest(client, elytraSlot);
        }
    }

    public static void swapOffhand(MinecraftClient client) {
        if (!canSwap(client)) return;
        TVConfig cfg = TVConfig.get();
        String a = normalizeId(cfg.offhandItemA);
        String b = normalizeId(cfg.offhandItemB);
        String held = Registries.ITEM.getId(client.player.getOffHandStack().getItem()).toString();
        String wanted = held.equals(a) ? b : a;
        int slot = findInventorySlot(client, wanted);
        if (slot < 0) {
            client.player.sendMessage(net.minecraft.text.Text.literal("§c[TankVisuals] Не найден предмет: " + wanted), true);
            return;
        }
        client.interactionManager.clickSlot(0, slot, 40, SlotActionType.SWAP, client.player);
    }

    private static boolean canSwap(MinecraftClient client) {
        return client.player != null && client.world != null && client.interactionManager != null && client.currentScreen == null;
    }

    private static void swapIntoChest(MinecraftClient client, int sourceSlot) {
        // Player inventory screen slot 6 is the chest armor slot. SWAP works directly for hotbar items.
        if (sourceSlot >= 36 && sourceSlot <= 44) {
            client.interactionManager.clickSlot(0, 6, sourceSlot - 36, SlotActionType.SWAP, client.player);
            return;
        }
        // Main inventory items are moved with a normal three-click pickup sequence.
        client.interactionManager.clickSlot(0, sourceSlot, 0, SlotActionType.PICKUP, client.player);
        client.interactionManager.clickSlot(0, 6, 0, SlotActionType.PICKUP, client.player);
        client.interactionManager.clickSlot(0, sourceSlot, 0, SlotActionType.PICKUP, client.player);
    }

    private static int findInventorySlot(MinecraftClient client, String... ids) {
        PlayerInventory inv = client.player.getInventory();
        for (int i = 0; i < inv.main.size(); i++) {
            ItemStack stack = inv.main.get(i);
            if (stack.isEmpty()) continue;
            String id = Registries.ITEM.getId(stack.getItem()).toString();
            for (String candidate : ids) if (id.equals(normalizeId(candidate))) return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    private static String normalizeId(String value) {
        if (value == null || value.isBlank()) return "minecraft:golden_apple";
        String trimmed = value.trim().toLowerCase(java.util.Locale.ROOT);
        return trimmed.contains(":") ? trimmed : "minecraft:" + trimmed;
    }
}
