package com.tankvisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class TankVisualsScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget itemAField;
    private TextFieldWidget itemBField;
    private String waitingForBind = "";
    private String status = "";

    public TankVisualsScreen() { this(null); }
    public TankVisualsScreen(Screen parent) {
        super(Text.literal("TankVisuals"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        TVConfig c = TVConfig.get();
        int center = width / 2;
        int left = center - 190;
        int right = center + 10;
        int y = Math.max(42, height / 2 - 145);
        int bw = 180;
        int bh = 20;
        addDrawableChild(toggle("Player HUD", () -> c.playerHud, v -> c.playerHud = v, left, y, bw, bh));
        addDrawableChild(toggle("Target circle", () -> c.targetCircle, v -> c.targetCircle = v, right, y, bw, bh));
        y += 25;
        addDrawableChild(toggle("Lightweight rendering", () -> c.lightweightRendering, v -> c.lightweightRendering = v, left, y, bw, bh));
        addDrawableChild(toggle("Elytra swap", () -> c.elytraSwap, v -> c.elytraSwap = v, right, y, bw, bh));
        y += 25;
        addDrawableChild(toggle("Offhand item swap", () -> c.offhandSwap, v -> c.offhandSwap = v, left, y, bw, bh));
        addDrawableChild(ButtonWidget.builder(Text.literal("Circle colour"), b -> {
            c.circleColor = c.circleColor == 0xFF55DDEE ? 0xFFFF6688 : c.circleColor == 0xFFFF6688 ? 0xFF9D7BFF : 0xFF55DDEE;
            TVConfig.save(); status = "Colour changed";
        }).dimensions(right, y, bw, bh).build());
        y += 32;
        addDrawableChild(ButtonWidget.builder(Text.literal("Elytra key: " + TankVisualsClient.elytraKey.getBoundKeyLocalizedText().getString()), b -> {
            waitingForBind = "elytra"; status = "Press a key for Elytra Swap...";
        }).dimensions(left, y, bw, bh).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Offhand key: " + TankVisualsClient.offhandKey.getBoundKeyLocalizedText().getString()), b -> {
            waitingForBind = "offhand"; status = "Press a key for Item Swap...";
        }).dimensions(right, y, bw, bh).build());
        y += 30;
        itemAField = new TextFieldWidget(textRenderer, left, y, bw, 20, Text.literal("First item ID"));
        itemAField.setMaxLength(96);
        itemAField.setText(c.offhandItemA);
        itemAField.setPlaceholder(Text.literal("minecraft:golden_apple"));
        addDrawableChild(itemAField);
        itemBField = new TextFieldWidget(textRenderer, right, y, bw, 20, Text.literal("Second item ID"));
        itemBField.setMaxLength(96);
        itemBField.setText(c.offhandItemB);
        itemBField.setPlaceholder(Text.literal("minecraft:shield"));
        addDrawableChild(itemBField);
        y += 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Save item IDs"), b -> {
            c.offhandItemA = itemAField.getText().trim();
            c.offhandItemB = itemBField.getText().trim();
            TVConfig.save(); status = "Settings saved";
        }).dimensions(left, y, bw, bh).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset defaults"), b -> {
            c.playerHud = true; c.targetCircle = true; c.lightweightRendering = true;
            c.elytraSwap = true; c.offhandSwap = true; c.offhandItemA = "minecraft:golden_apple";
            c.offhandItemB = "minecraft:shield"; c.circleColor = 0xFF55DDEE; c.circleRadius = 0.72;
            TVConfig.save(); clearAndInit();
        }).dimensions(right, y, bw, bh).build());
        y += 30;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(center - 90, y, 180, 22).build());
    }

    private ButtonWidget toggle(String label, java.util.function.Supplier<Boolean> getter, java.util.function.Consumer<Boolean> setter,
                                int x, int y, int w, int h) {
        return ButtonWidget.builder(toggleText(label, getter.get()), button -> {
            boolean next = !getter.get(); setter.accept(next); button.setMessage(toggleText(label, next)); TVConfig.save();
        }).dimensions(x, y, w, h).build();
    }

    private Text toggleText(String label, boolean on) { return Text.literal(label + ": " + (on ? "ON" : "OFF")); }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!waitingForBind.isEmpty()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                waitingForBind = ""; status = "Key assignment cancelled"; return true;
            }
            InputUtil.Key key = InputUtil.fromKeyCode(keyCode, scanCode);
            if (waitingForBind.equals("elytra")) TankVisualsClient.elytraKey.setBoundKey(key);
            if (waitingForBind.equals("offhand")) TankVisualsClient.offhandKey.setBoundKey(key);
            waitingForBind = "";
            net.minecraft.client.option.KeyBinding.updateKeysByCode();
            TVConfig.save(); clearAndInit();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int center = width / 2;
        context.fill(center - 205, Math.max(20, height / 2 - 175), center + 205, Math.min(height - 18, height / 2 + 176), 0xE610141D);
        context.fill(center - 205, Math.max(20, height / 2 - 175), center + 205, Math.max(23, height / 2 - 172), TVConfig.get().circleColor);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("TANK VISUALS"), center, Math.max(27, height / 2 - 165), 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Minecraft 1.21.4  •  Fabric client mod"), center, Math.max(40, height / 2 - 150), 0xFF9AA8BC);
        super.render(context, mouseX, mouseY, delta);
        if (!status.isEmpty()) context.drawCenteredTextWithShadow(textRenderer, Text.literal(status), center, Math.min(height - 32, height / 2 + 153), 0xFFFFD479);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Item IDs: minecraft:golden_apple, minecraft:shield, etc."), center, Math.min(height - 18, height / 2 + 166), 0xFF9AA8BC);
    }

    @Override
    public void close() {
        TVConfig.get().offhandItemA = itemAField == null ? TVConfig.get().offhandItemA : itemAField.getText().trim();
        TVConfig.get().offhandItemB = itemBField == null ? TVConfig.get().offhandItemB : itemBField.getText().trim();
        TVConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
