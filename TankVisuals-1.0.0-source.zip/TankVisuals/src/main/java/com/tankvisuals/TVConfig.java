package com.tankvisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class TVConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("tankvisuals.json");
    private static TVConfig instance;

    public boolean playerHud = true;
    public boolean targetCircle = true;
    public boolean lightweightRendering = true;
    public boolean elytraSwap = true;
    public boolean offhandSwap = true;
    public boolean showTargetRange = false;
    public String offhandItemA = "minecraft:golden_apple";
    public String offhandItemB = "minecraft:shield";
    public int circleColor = 0xFF55DDEE;
    public double circleRadius = 0.72;

    public static TVConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                TVConfig loaded = GSON.fromJson(Files.readString(FILE), TVConfig.class);
                instance = loaded == null ? new TVConfig() : loaded;
            } else {
                instance = new TVConfig();
            }
        } catch (Exception e) {
            instance = new TVConfig();
            System.err.println("[TankVisuals] Could not read config: " + e.getMessage());
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(getWithoutReload()));
        } catch (IOException e) {
            System.err.println("[TankVisuals] Could not save config: " + e.getMessage());
        }
    }

    private static TVConfig getWithoutReload() {
        if (instance == null) instance = new TVConfig();
        return instance;
    }
}
